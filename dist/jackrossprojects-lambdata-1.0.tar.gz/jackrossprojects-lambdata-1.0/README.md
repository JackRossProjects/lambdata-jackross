# lambdata

1.) Navigate to directory<br>
2.) pipenv install<br>
3.) For classes assignment - python -m my_lambdata.closet_class<br>
4.) NaN dropper for dataframes - python -m my_lambdata.my_script<br>

Available at https://test.pypi.org/project/jackrossprojects-lambdata/1.0/#files
